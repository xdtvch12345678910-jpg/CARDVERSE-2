CARDVERSE V19
- Replaced the old single Main Card editor on Profile with the same two-card presentation style used on Home.
- Supports TWO independently selected main cards.
- Each slot can choose any card from the card list or upload its own image.
- Each uploaded card has independent position X/Y and zoom controls.
- Each uploaded card can have its own name/game/rarity.
- Profile image upload is rebound with a robust file-change handler and stored as compressed JPEG data in localStorage.
- Profile image position X/Y/zoom persists.
- Old single mainCard state is migrated to slot 1 automatically.
- Home page displays both selected main cards.
