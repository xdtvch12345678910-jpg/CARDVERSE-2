CARDVERSE V11 CARD ART

Replace these files with your own character images when ready:
jinhsi.svg
phrolova.svg
changli.svg
yinlin.svg
shorekeeper.svg
jiyan.svg
rover.svg

You can use PNG/JPG too; if you change an extension, update the matching path in app.js and profile.html.
The game logic does not depend on the artwork files.
