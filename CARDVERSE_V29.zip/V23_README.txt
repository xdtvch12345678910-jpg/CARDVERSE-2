CARDVERSE V23
- Restored ONE Main Card visual on the Lobby right side.
- Lobby Main Card uses the same selected Main Card state as Profile.
- Removed the old TWO-card Profile UI.
- Profile now has one Main Card selector/customizer.
- Upload custom card, edit name/game/rarity, and adjust image position/zoom.
- Main Card updates on Lobby and Profile.
- Existing profile-position fix and Gacha sound remain.
