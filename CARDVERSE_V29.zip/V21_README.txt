CARDVERSE V21
- Removed the incorrect two-main-card system.
- Profile now has ONE Main Card customizer.
- Upload a card image from your computer and set it as Main Card.
- Adjust card image X/Y position and zoom.
- Choose one built-in card from the picker.
- Profile avatar upload is handled by a dedicated stable input listener.
- Added local Web Audio gacha sound when opening/revealing cards.
- No external music dependency for the gacha sound.
