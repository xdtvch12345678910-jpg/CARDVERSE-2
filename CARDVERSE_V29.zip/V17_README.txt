CARDVERSE V17 — FIXED

1. Image loader now supports PNG/JPG/JPEG/WEBP/GIF/SVG.
2. It checks the project root, assets/cards, and assets.
3. Your exact names such as Changli_Card, Jinhsi_Card, Yinlin_Card, Lingyang_Card, Carlotta_Card, Jianxin_Card, Shorekeeper_Card, Hiyuki_Card, Suisui_Card, Denia_Card, Qingxiao_Card, Aemeath_Card are supported.
4. If the real image is present, it is used first. If not, the built-in SVG fallback is used instead of a blank image.
5. Selecting a profile image saves immediately.
6. Selecting a main card saves immediately and updates the home page and profile preview.
7. Global CARDVERSE MUSIC is initialized on every page. Because browsers block autoplay, click the music button once; the state/time is then remembered.

IMPORTANT: Put your real card files beside the HTML files or in assets/cards. Keep the visible base names, e.g. Changli_Card.png.
