CARDVERSE V20
- Removed the home-page main card/featured card display that was shown in the user's screenshot.
- Removed the V19 two-card home section.
- Main-card customization remains on profile.html only, with two selectable card slots.
- Added CSS guard to prevent legacy main-card home blocks from displaying.
